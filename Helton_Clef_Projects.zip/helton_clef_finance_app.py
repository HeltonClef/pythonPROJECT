class FinanceApp:
    def __init__(self):
        self.balance = 50000
        self.transactions = []

    def login(self, username, password):
        return username == "clef" and password == "clef"

    def deposit(self, amount):
        self.balance += amount
        self.transactions.append(("Deposit", amount))

    def withdraw(self, amount):
        if amount <= self.balance:
            self.balance -= amount
            self.transactions.append(("Withdrawal", amount))
            return True
        else:
            return False

    def show_balance(self):
        return self.balance

    def show_transactions(self):
        return self.transactions

if __name__ == "__main__":
    app = FinanceApp()
    if app.login("clef", "clef"):
        print("Login successful! Welcome to Helton Clef Finance App.")
        app.deposit(1000)
        app.withdraw(500)
        print("Current Balance: $", app.show_balance())
        print("Transaction History:")
        for t in app.show_transactions():
            color = "\033[92m" if t[0] == "Deposit" else "\033[91m"
            print(f"{color}{t[0]}: ${t[1]}\033[0m")
    else:
        print("Login failed.")