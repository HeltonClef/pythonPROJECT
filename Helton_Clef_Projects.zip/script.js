function login() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (username === "clef" && password === "clef") {
    alert("Login successful!");
    window.location.href = "dashboard.html"; // hypothetical next page
  } else {
    document.getElementById("login-error").textContent = "Invalid credentials!";
  }
}